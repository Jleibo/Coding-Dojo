var Minimum_Height = 42;
var Rider_Height = 45;
if (Rider_Height >= Minimum_Height) {
    console.log("Get on That Ride Kiddo");
}
else {
    console.log("Sorry kiddo. Maybe next year");
} 