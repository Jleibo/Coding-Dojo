var Minimum_Height = 42;
var Minimum_Age = 10;
var Rider_Height = 45;
var Rider_Age = 14;
if (Rider_Height >= Minimum_Height || Rider_Age >= Minimum_Age) {
    console.log("Get on That Ride Kiddo");
}
else {
    console.log("Sorry kiddo. Maybe next year");
} 