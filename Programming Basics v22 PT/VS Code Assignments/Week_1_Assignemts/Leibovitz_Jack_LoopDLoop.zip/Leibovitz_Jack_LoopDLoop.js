var x = Distance
for (var x = 0; x < 6; x += 2){
    console.log("PieceOfCandy")
}

// var x = Distance
// var y = Speed
    for (var x = 0; x < 6; x += 2){
        if (x > 2 && y > 5.5 )
    console.log("PieceOfCandy")
}