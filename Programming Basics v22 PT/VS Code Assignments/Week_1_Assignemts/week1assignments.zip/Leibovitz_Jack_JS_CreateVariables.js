//var for rollercoaster fun
var Minimum_Height = 42;
var Minimum_Age = 10;