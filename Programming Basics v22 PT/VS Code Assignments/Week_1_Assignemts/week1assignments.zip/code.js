// set the numebr of likes
var likeCount = 0;
//set the count to zero
function increaseLikes(){
    //this is addition
    likeCount = likeCount + 1;
}