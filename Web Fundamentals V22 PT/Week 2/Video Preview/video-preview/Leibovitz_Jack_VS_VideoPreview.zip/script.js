console.log("page loaded...");

function playClip(element) {
    element.play();
}
function pauseClip(element) {
    element.pause();
}