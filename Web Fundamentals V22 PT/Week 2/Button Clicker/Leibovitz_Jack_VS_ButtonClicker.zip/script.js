function login(element) {
    element.innerText = "log out"
}

function hide(element) {
    element.remove();
}